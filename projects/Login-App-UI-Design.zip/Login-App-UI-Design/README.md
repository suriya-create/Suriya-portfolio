# 📱 Login Screen – Figma UI Design

This repository contains a single exported UI screen created in *Figma*.  
The design represents a clean and modern mobile *Login Screen*.

---

## 📸 Preview
Below is the design included in this project:

[Login App Preview]<img width="1366" height="768" alt="login-screen-ui png" src="https://github.com/user-attachments/assets/b5f2dee7-ff0d-407a-9f13-89165aaa43ac" />


---

## 🎨 Tools Used
- Figma

---

## 👨‍💻 Designer
Suriya  
UI/UX Designer
